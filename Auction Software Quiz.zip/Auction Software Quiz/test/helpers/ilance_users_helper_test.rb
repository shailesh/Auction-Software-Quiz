require 'test_helper'

class IlanceUsersHelperTest < ActionView::TestCase
end
