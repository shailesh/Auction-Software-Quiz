require 'test_helper'

class IlanceProjectsHelperTest < ActionView::TestCase
end
