require 'test_helper'

class IlanceCategoriesHelperTest < ActionView::TestCase
end
