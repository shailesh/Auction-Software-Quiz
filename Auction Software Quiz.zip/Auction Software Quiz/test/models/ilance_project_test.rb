require 'test_helper'

class IlanceProjectTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
