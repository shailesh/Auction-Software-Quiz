require 'test_helper'

class IlanceCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
